local mainframe = CreateFrame("FRAME", "SpecMenuPopupFrame", UIParent,"UIPanelDialogTemplate")
    mainframe:SetPoint("CENTER",0,0);
    mainframe:SetSize(500,120);
    mainframe:EnableMouse(true);
    mainframe:SetMovable(true);
    mainframe:RegisterForDrag("LeftButton");
    mainframe:SetScript("OnDragStart", function(self) mainframe:StartMoving() end)
    mainframe:SetScript("OnDragStop", function(self) mainframe:StopMovingOrSizing() end)
    mainframe.TitleText = mainframe:CreateFontString();
    mainframe.TitleText:SetFont("Fonts\\FRIZQT__.TTF", 12)
    mainframe.TitleText:SetFontObject(GameFontNormal)
    mainframe.TitleText:SetText("Spec Change Popup");
    mainframe.TitleText:SetPoint("TOP", 0, -9);
    mainframe.TitleText:SetShadowOffset(1,-1);
    mainframe:Hide();

local petbutton = CreateFrame("Button", "SpecMenuPopupFrame_BankPet", SpecMenuPopupFrame, "SecureActionButtonTemplate");
    petbutton:SetSize(120,40);
    petbutton:SetPoint("TOPLEFT", SpecMenuPopupFrame, "TOPLEFT", 20, -30);
    petbutton:SetAttribute("type1", "spell");
    petbutton:SetAttribute("spell","Treasure Keeper");
    petbutton:RegisterForClicks("LeftButtonUp");
    petbutton:SetNormalTexture("Interface/Buttons/UI-Panel-Button-Up")
    petbutton:SetHeight(28)
    petbutton:SetPushedTexture("Interface/Buttons/UI-Panel-Button-Down")
    petbutton:SetHeight(28)
            local tex = petbutton:GetNormalTexture();
            tex:SetTexCoord(0, 0.6640625, 0, 0.8);
            tex:SetHeight(40)

            local tex2 = petbutton:GetPushedTexture();
            tex2:SetTexCoord(0, 0.6640625, 0, 0.8);
            tex2:SetHeight(40)
    petbutton.Lable = petbutton:CreateFontString(nil , "OVERLAY", "GameFontNormal");
	petbutton.Lable:SetJustifyH("CENTER");
	petbutton.Lable:SetPoint("CENTER", petbutton, "CENTER", 0, 0);
	petbutton.Lable:SetText("Summon Bank");
    petbutton:Show();
